jQuery(document).ready(() => {

    jQuery('body')[0].scrollLeft = 0

    setEventListeners()
})

function setEventListeners(){}